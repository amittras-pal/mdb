import {
  faFeather,
  faFire,
  faHome,
  faPowerOff,
  faStar,
  faTrophy,
  faTv,
  faUsers,
  faVideo,
} from "@fortawesome/free-solid-svg-icons";

export const menu = [
  {
    menuHeading: "Discover",
    menuItems: [
      { id: "home", label: "Home", icon: faHome },
      // { id: "discover", label: "Discover", icon: faCompass },
      { id: "awards", label: "Awards", icon: faTrophy },
      { id: "celebs", label: "Celebs", icon: faUsers },
      { id: "trending", label: "Trending", icon: faFire },
      { id: "topRated", label: "Top Rated", icon: faStar },
    ],
  },
  // {
  //   menuHeading: "Library",
  //   menuItems: [
  //     { id: "awards", label: "Awards", icon: faTrophy },
  //     { id: "celebs", label: "Celebs", icon: faUsers },
  //     { id: "trending", label: "Trending", icon: faFire },
  //     { id: "topRated", label: "Top Rated", icon: faStar },
  //   ],
  // },
  {
    menuHeading: "Categories",
    menuItems: [
      { id: "tvShows", label: "TV Shows", icon: faTv },
      { id: "movies", label: "Movies", icon: faVideo },
      { id: "anime", label: "Anime", icon: faFeather },
    ],
  },
  {
    menuHeading: "General",
    menuItems: [{ id: "logout", label: "Logout", icon: faPowerOff }],
  },
];
