import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import imdbLogo from "../../../resources/images/imdb.png";
import "./MovieTile.scss";

function MovieTile({ movie }) {
  return (
    <div className="movie">
      <img
        className="movie__poster"
        src={movie.image}
        alt="John Wick: Chapter 3"
      />
      <div className="movie__details">
        <div className="title">
          <div className="name">
            <span>{movie.title}</span>
            <button className="info-btn">
              <FontAwesomeIcon icon={faInfoCircle} />
            </button>
          </div>
          <div className="year">{movie.year}</div>
        </div>
        <div className="meta">
          <div className="genres">{movie.genres}</div>
          <div className="rating">
            <img src={imdbLogo} alt="" />
            <span className="label">{movie.imdbRating}</span>
            <span className="over">/10</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MovieTile;
