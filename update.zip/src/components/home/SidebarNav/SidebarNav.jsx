import { faTimes } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import { isMobile } from "react-device-detect";
import { menu } from "../../../constants/menuItems";
import "./SidebarNav.scss";

function SidebarNav({ onCloseRequested }) {
  const [activeLink, setActiveLink] = useState(menu[0].menuItems[0].id);

  const changeActiveLink = (e) => {
    setActiveLink(e);
    setTimeout(() => {
      onCloseRequested();
    }, 450);
  };

  return (
    <nav
      className={`sidebar ${
        isMobile ? "sidebar--controlled" : "sidebar--static"
      } `}
    >
      <div className="d-flex justify-content-between align-items-center w-100 sidebar__header">
        <h4>Exxom</h4>
        {isMobile && (
          <button className="btn text-danger" onClick={onCloseRequested}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        )}
      </div>
      {menu.map((section) => (
        <div key={section.menuHeading} className="sidebar__section">
          <div className="sidebar__heading">{section.menuHeading}</div>
          <ul className="sidebar__nav">
            {section.menuItems.map((item) => (
              <button
                key={item.id}
                className={`sidebar__nav__button ${
                  activeLink === item.id ? "active" : ""
                }`}
                onClick={() => changeActiveLink(item.id)}
              >
                <span className="icon-container">
                  <FontAwesomeIcon icon={item.icon} />
                </span>
                <span className="label">{item.label}</span>
              </button>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );
}

export default SidebarNav;
