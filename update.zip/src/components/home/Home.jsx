import { faBars, faSearch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useState } from "react";
import { isMobile } from "react-device-detect";
import "../../resources/theme/style.scss";
import SingleMovie from "../shared/SingleMovie/SingleMovie";
import "./Home.scss";
import SidebarNav from "./SidebarNav/SidebarNav";

function Home() {
  const [sidenavShow, setSidenavShow] = useState(false);
  return (
    <div className="home row m-0 p-0">
      <div
        className={`col-md-2 col-lg-2 px-0 h-100 left-sidebar ${
          isMobile ? "controlled" : ""
        } ${sidenavShow ? "open" : "closed"}`}
      >
        <SidebarNav onCloseRequested={() => setSidenavShow(false)} />
      </div>
      <div className="col-md-10 col-lg-10 col-sm-12 px-0 main">
        <div className="app-header d-flex align-items-center">
          {isMobile && (
            <div className="app-title d-flex align-items-center">
              <button
                className="btn ps-0 "
                disabled={!isMobile}
                onClick={() => setSidenavShow(!sidenavShow)}
              >
                <FontAwesomeIcon icon={faBars} className="text-danger" />
              </button>
              <h4 className="m-0">Exxmon</h4>
            </div>
          )}
          <form className=" ms-auto">
            <div className="input-container d-flex justify-content-between align-items-center">
              <FontAwesomeIcon icon={faSearch} className="me-2" />
              <input type="text" placeholder="Search..." />
            </div>
          </form>
        </div>
        <div className="home-content">
          <div className="row m-0">
            <div className="col-md-6 col-lg-6 col-sm-12">
              <SingleMovie />
            </div>
            <div className="col-md-6 col-lg-6 col-sm-12">
              <SingleMovie />
            </div>
          </div>
          <div className="movie_card" id="bright">
            <div className="info_section">
              <div className="movie_header">
                <img
                  className="locandina"
                  src="https://movieplayer.net-cdn.it/t/images/2017/12/20/bright_jpg_191x283_crop_q85.jpg"
                />
                <h1>Shang Chi </h1>
                <h4>2017, David Ayer</h4>
                <span className="minutes">117 min</span>
                <p className="type">Action, Crime, Fantasy</p>
              </div>
              <div className="movie_desc">
                <p className="text">
                  Set in a world where fantasy creatures live side by side with
                  humans. A human cop is forced to work with an Orc to find a
                  weapon everyone is prepared to kill for.
                </p>
              </div>
              <div className="movie_social">
                <ul>
                  <li>
                    <i className="material-icons">share</i>
                  </li>
                  <li>
                    <i className="material-icons"></i>
                  </li>
                  <li>
                    <i className="material-icons">chat_bubble</i>
                  </li>
                </ul>
              </div>
            </div>
            <div className="blur_back bright_back"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
