import { TOGGLE_SIDEBAR } from "../constants/actions";

export const toggleSidebar = () => {
  return {
    type: TOGGLE_SIDEBAR,
  };
};
