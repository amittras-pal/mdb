import React from "react";

function Movies() {
  return (
    <div>
      <h3>List of Movies!!</h3>
    </div>
  );
}

export default Movies;
