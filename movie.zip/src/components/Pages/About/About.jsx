import React from "react";
import "./About.scss";
// import tmdbLogo from "../../resources/images/tmdb-logo.svg";

function About() {
  return (
    <div className="about row m-0">
      {/* <div className="attrib">
        <p className="text-secondary m-0">
          This product uses the <span className="fw-bold">TMDB API</span> but is
          not endorsed or certified by TMDB.
        </p>
        <img src={tmdbLogo} alt="" />
      </div> */}
      <div className="about-scroll">
        <h3>About Page</h3>
        <h5>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Beatae
          molestias veniam ullam ipsum, ut, recusandae quas voluptas praesentium
          rerum necessitatibus iure consectetur dolorem, sapiente magni tempora
          possimus deserunt laboriosam minima! Labore accusantium impedit,
          perspiciatis et provident repellat. Ullam sequi eveniet culpa, veniam
          quibusdam dignissimos, in vero autem sapiente cum officia optio
          inventore at est deserunt iste dolorem libero blanditiis commodi.
          Velit distinctio a, facere rem quod itaque eligendi hic iste
          reiciendis illum aliquid aperiam accusamus laborum eius aut debitis,
          harum in repudiandae? Ducimus voluptate dolorum accusamus asperiores
          corporis ipsum sit architecto odio impedit ad porro, perferendis
          molestiae iusto sequi culpa aut ea in natus laudantium nobis
          repudiandae odit hic deserunt. Vel, repellat, voluptates nulla
          accusamus aperiam ullam odio omnis a, reiciendis fugiat possimus sint
          hic ratione! Voluptates maiores pariatur porro velit, nihil, ut, odio
          dolorum ipsa repellat modi fugit repudiandae ab officia! Ratione
          aspernatur neque, vel aliquam natus quaerat amet debitis tempora quia,
          autem perspiciatis similique tempore, quae dicta asperiores eaque
          vitae rerum nobis laudantium voluptatibus saepe labore sunt pariatur
          quo. Illo consequuntur delectus aut obcaecati animi quam sequi
          incidunt natus? Dolorum omnis dicta, quo incidunt atque recusandae
          dolor at sint corporis ullam cum inventore enim expedita, autem, ipsam
          rerum?
        </h5>
      </div>
    </div>
  );
}

export default About;
