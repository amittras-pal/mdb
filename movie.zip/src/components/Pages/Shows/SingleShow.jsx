import React from "react";

function SingleShow() {
  return (
    <div>
      <h3>Single TV Show Details Page</h3>
    </div>
  );
}

export default SingleShow;
