import React from "react";

function Shows() {
  return (
    <div>
      <h3>List of TV Shows</h3>
    </div>
  );
}

export default Shows;
