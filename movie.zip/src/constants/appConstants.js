export const APP_TITLE = "IntelliShows.";
