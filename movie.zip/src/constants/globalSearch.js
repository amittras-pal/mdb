export const searchCategories = {
  PERSON: "person",
  MOVIE: "movie",
  TV: "tv",
};
